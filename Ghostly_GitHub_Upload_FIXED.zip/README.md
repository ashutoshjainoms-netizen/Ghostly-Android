# Ghostly Android — Binary Release

This repository contains an APK supplied by the project owner for archival/release purposes.

## Release
- Version: 1.1.6 (Contact Inspection)
- File: `releases/Ghostly_1.1.6_Contact_Inspection.apk`

## Important
This repository does **not** contain the Android Studio source code and should not be described as an open-source code contribution. The APK has not been independently security-audited or tested here.

To publish the original source, upload the Android Studio project separately after removing secrets and personal data.
